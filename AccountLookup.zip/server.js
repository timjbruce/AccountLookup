'use strict';

const express = require('express');
const bodyParser = require('body-parser');

var AWS = require('aws-sdk');
AWS.config.update({region: 'us-west-1'});

const PORT = 8080;
const HOST = '0.0.0.0';

const app = express();
app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));

var return_val = '';

app.get('/', (req, res) => {
  //res.send('Hello World\n');
  res.render('index');
});
var ddb = new AWS.DynamoDB({apiVersion: '2012-10-08'});

app.post('/', (req, res) => {
  //res.render('details');
  let account = req.body.Account;
  let ddb_params = {
    TableName: 'Accounts',
    Key: {'AccountNumber':{'N':account}}
  };

// Call DynamoDB to add the item to the table
  ddb.getItem(ddb_params, function(err, data) {
    if (err) {
      console.log("Error adding record to Dynamo", err);
      return_val = 'Error: ' + err;
    } else {
      console.log("Success", data);
      //res.render('details', {title: 'Account Detail', account: data.Item);
      res.send(data.Item);
      //call batch to add the new record to the batch cycle - only do this on
      //successful adds to dynamo
    }
  });

});

app.listen(PORT, HOST);
console.log('Running on http://'+HOST+':'+PORT);
